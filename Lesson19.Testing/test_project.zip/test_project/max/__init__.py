def max_(a, b):
    return b
    if a > b:
        return a

    return b
